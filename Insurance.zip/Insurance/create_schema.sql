ALTER TABLE car
DROP car_type;