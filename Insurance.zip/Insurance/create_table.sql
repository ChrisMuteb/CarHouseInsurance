CREATE TABLE IF NOT EXISTS `insurance`.`AGENT` (
  `agent_id` INT NOT NULL,
  `agent_name` VARCHAR(45) NULL,
  `agent_username` VARCHAR(45) NULL,
  `agent_psw` VARCHAR(45) NULL,
  PRIMARY KEY (`agent_id`))
ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS `insurance`.`CUSTOMER` (
  `cust_id` INT NOT NULL,
  `cust_name` VARCHAR(45) NULL,
  `cust_addr` VARCHAR(45) NULL,
  `cust_username` VARCHAR(45) NULL,
  `cust_psw` VARCHAR(45) NULL,
  `agent_id` INT NULL,
  PRIMARY KEY (`cust_id`),
  INDEX `agent_id_idx` (`agent_id` ASC) VISIBLE,
  CONSTRAINT `agent_customer_id`
    FOREIGN KEY (`agent_id`)
    REFERENCES `insurance`.`AGENT` (`agent_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS `insurance`.`CAR` (
  `car_id` INT NOT NULL,
  `year_produced` DATE NULL,
  `horse_power` INT NULL,
  `cost` DECIMAL(9,2) NULL,
  `year_build` DATE NULL,
  `cust_id` INT NULL,
  PRIMARY KEY (`car_id`),
  INDEX `cust_id_idx` (`cust_id` ASC) VISIBLE,
  CONSTRAINT `cust_id`
    FOREIGN KEY (`cust_id`)
    REFERENCES `insurance`.`CUSTOMER` (`cust_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS `insurance`.`HOUSE` (
  `house_id` INT NOT NULL,
  `house_addr` VARCHAR(45) NULL,
  `num_floor` VARCHAR(45) NULL,
  `occupant` VARCHAR(45) NULL,
  `cust_id` INT NULL,
  PRIMARY KEY (`house_id`),
  INDEX `cust_id_idx` (`cust_id` ASC) VISIBLE,
  CONSTRAINT `cust_house_id`
    FOREIGN KEY (`cust_id`)
    REFERENCES `insurance`.`CUSTOMER` (`cust_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS `insurance`.`POLICY` (
  `policy_id` INT NOT NULL,
  `title` VARCHAR(45) NULL,
  `comment` VARCHAR(45) NULL,
  `agent_id` INT NULL,
  PRIMARY KEY (`policy_id`),
  INDEX `agent_id_idx` (`agent_id` ASC) VISIBLE,
  CONSTRAINT `agent_policy_id`
    FOREIGN KEY (`agent_id`)
    REFERENCES `insurance`.`AGENT` (`agent_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS `insurance`.`PAYMENT` (
  `payment_id` INT NOT NULL,
  `amount` DECIMAL(9,2) NULL,
  `received_date` DATE NULL,
  `due_date` DATE NULL,
  `agent_id` INT NULL,
  PRIMARY KEY (`payment_id`),
  INDEX `agent_id_idx` (`agent_id` ASC) VISIBLE,
  CONSTRAINT `agent_payment_id`
    FOREIGN KEY (`agent_id`)
    REFERENCES `insurance`.`AGENT` (`agent_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;